package view;

import Logic.GameEngine;
import Logic.ICrosser;
import javafx.animation.AnimationTimer;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.CrossRiverButton;
import model.FARMER;
import model.SHIP;
import model.HERBANIMAL;
import model.CARNANIMAL;
import model.PLANTS;
import javafx.scene.image.ImageView;

import javafx.scene.effect.DropShadow;

import java.util.LinkedList;
import java.util.List;

public class GameViewManger {
    private AnchorPane gamePane;
    private Scene gameScene;
    private Stage gameStage;
    private Stage menuStage;

    private ImageView ship, farmerImage, herbAnimalImage, carnAnimalImage, plantImage,farmerA,farmerB,farmerC,farmerD,deadFarmers;
    private ImageView saveButton, redoButton, undoButton, backButton, numbersUnits , numbersTenth;
    private Image idleship, reversedShip;
    private Image idleFarmer, deadFarmer, JumpFarmer;
    private Image idleHerbAnimal, selectedHerbAnimal, deadHerbAnimal;
    private Image idleCarnAnimal, selectedCarnAnimal, killCarnAnimal, deadCarnAnimal;
    private Image plant, eatenPlant;
    private Image idleFarmerA,JumpFarmerA;
    private Image idleFarmerB,JumpFarmerB;
    private Image idleFarmerC,JumpFarmerC;
    private Image idleFarmerD,JumpFarmerD;
    private int numberOfMoves=0;

    GameEngine startGameLogic;
    private static final int GAME_WIDTH = 1250;
    private static final int GAME_HIGHT = 700;
    private int storyNumber;

    private boolean isFarmerClicked=false, letsgoButtonisClicked=false;
    private boolean isHerbAnimalClicked=false, isCarnAnimalClicked =false, isPlantClicked=false;
    private boolean endOfBank= true;
    private boolean blabla = true;
    private int angle;

    private AnimationTimer gameTimer;
    private GridPane gridPane1;
    private GridPane gridPane2;
    private final static String BACKGROUND_IMAGE = "view/resources/River.jpeg";
    private final static String BACKGROUND_IMAGE2 = "view/resources/Sky.png";
    private final static String GameOVERBACKGROUND_IMAGE= "view/resources/Back.png";
    private Scene gameOver;
    List<ICrosser> boatRiders = new LinkedList<ICrosser>();

    SHIP choosenShip;
    FARMER choosenFarmer;
    HERBANIMAL choosenHerbAnimal;
    CARNANIMAL choosenCarnAnimal;
    PLANTS choosenPlants;
    //Passing the GameEngine object from the ViewManger.
    public GameViewManger(GameEngine startGameLogic){
        //Set the Scene and hight, Width of the game.
        initStage();
        this.startGameLogic = startGameLogic;
        //to init. the boat side on the left bank.
        startGameLogic.setLetsGoButtonClicked(true);
        startGameLogic.setCrossersOnboat(null);
    }

    private CrossRiverButton createLetsGoButton(){
        CrossRiverButton letsGoButton = new CrossRiverButton("Let's GO");
        letsGoButton.setLayoutX(GAME_WIDTH/2);
        letsGoButton.setLayoutY(100);
        letsGoButton.setOnAction(e->{
            startGameLogic.REDOLIST(startGameLogic.story1RightBankList,startGameLogic.story1LeftBankList);
//            startGameLogic.IniStacks();
            //Check if this is the end of bank to avoid pressing on the button,
                //while the boat is moving.
            if (endOfBank && startGameLogic.isValidforBoat(boatRiders)) {
                letsgoButtonisClicked = true;

            } else {
                System.out.println("unvalid move, Farmer is not on boat");
                letsgoButtonisClicked = false;
            }
            if(letsgoButtonisClicked && endOfBank) {
                System.out.println("I will check validation for: ******");
                System.out.println("Right" + startGameLogic.story1RightBankList);
                System.out.println("Left" + startGameLogic.story1LeftBankList);
                if(startGameLogic.story1RightBankList.isEmpty()) {
                    System.out.println("WINERRR####################");
                    gameOverStoryone(1);
                }
                else if (startGameLogic.isValidFromLogic(startGameLogic.story1RightBankList, startGameLogic.story1LeftBankList, boatRiders)) {
                        System.out.println("@@@@@@@@ Valid Move @@@@@@@@");
                        numberOfMoves++;
                        System.out.println(numberOfMoves);
                }
                else {

                    System.out.println("***************************************");
                    System.out.println("GAME OVEEEER!!!!");
                    System.out.println("***************************************");
                    gameOverStoryone(2);
                }
            }
        });
        return letsGoButton;
    }
     private void RestGameOne(){
        startGameLogic.resetGame();
        startGameLogic.IniStacks();
        gameStage.close();
        initStage();
        boatRiders = null;
        boatRiders = new LinkedList<ICrosser>();
        startGameLogic.setLetsGoButtonClicked(true);
        startGameLogic.setCrossersOnboat(null);
        creatNewGame(menuStage,choosenShip,choosenFarmer,choosenHerbAnimal,choosenCarnAnimal,choosenPlants);
        gameStage.setScene(gameScene);
    }
    private void gameOverStoryone(int Case){
        Stage gameOverStage = new Stage();
        gameOverStage.initModality(Modality.APPLICATION_MODAL);

        AnchorPane root = new AnchorPane();

        GridPane gameOverLayout = new GridPane();
        gameOverLayout.setPadding(new Insets(20, 20, 20, 20)); //Setting gaps in corners
        gameOverLayout.setVgap(8);
        gameOverLayout.setHgap(10);

        BackgroundImage image = new BackgroundImage(new Image(GameOVERBACKGROUND_IMAGE,1000,300,false,true),
                BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,null);

        ImageView gameoverIcon = new ImageView("view/resources/gameOver.png");
        gameoverIcon.setLayoutX(300);
        gameoverIcon.setLayoutY(100);
        ImageView winnergameIcon = new ImageView("view/resources/Winner.png");
        winnergameIcon.setLayoutX(300);
        winnergameIcon.setLayoutY(100);
        ImageView exit = new ImageView("view/resources/Exit.png");
        exit.setLayoutX(10);
        exit.setLayoutY(10);
        ImageView playAgian = new ImageView("view/resources/playAgain.png");
        playAgian.setLayoutX(900);
        playAgian.setLayoutY(200);

        root.setBackground(new Background(image));

        playAgian.setOnMouseClicked(e->{
            RestGameOne();
            gameOverStage.close();
            blabla = false;
        });

        exit.setOnMouseClicked(e->{
            gameStage.close();
            ViewManger v = ViewManger.getInstance();
            startGameLogic.resetGame();
            startGameLogic.IniStacks();
            v.resetScene();
            v.mainStage.show();
            gameOverStage.close();
        });
        exit.setOnMouseEntered(e->{
            exit.setEffect(new DropShadow());
        });
        exit.setOnMouseExited(e->{
            exit.setEffect(null);
        });
        playAgian.setOnMouseEntered(e->{
            playAgian.setEffect(new DropShadow());
        });
        playAgian.setOnMouseExited(e->{
            playAgian.setEffect(null);
        });
        if(Case==2) {
            gameOverStage.setTitle("GAME OVER!!!");
            farmerImage.setImage(deadFarmer);
            herbAnimalImage.setImage(deadHerbAnimal);
            carnAnimalImage.setImage(deadCarnAnimal);
            plantImage.setImage(eatenPlant);
            root.getChildren().addAll(gameOverLayout, exit, playAgian, gameoverIcon);
        }
        else if(Case==1){
            gameOverStage.setTitle("WINNER!!");
            farmerImage.setImage(JumpFarmer);
            herbAnimalImage.setImage(selectedHerbAnimal);
            carnAnimalImage.setImage(selectedCarnAnimal);
            root.getChildren().addAll(gameOverLayout, exit, playAgian, winnergameIcon);
        }
        gameOver = new Scene(root, 1000,300);
        gameOverStage.setScene(gameOver);
//        gameOverStage.setAlwaysOnTop(true);
        gameOverStage.setX(100);
        gameOverStage.setY(100);
        gameOverStage.showAndWait();
        if(blabla) {
            gameStage.close();
            ViewManger v = ViewManger.getInstance();
            v.resetScene();
            v.mainStage.show();
        }
    }
    private void initStage() {
        gamePane = new AnchorPane();
        gameScene = new Scene(gamePane, GAME_WIDTH, GAME_HIGHT);
        gameStage = new Stage();
        gameStage.setScene(gameScene);
        saveButton = new ImageView("view/resources/Save.png");
        saveButton.setLayoutY(30);
        saveButton.setLayoutX(GAME_WIDTH-80);
        redoButton = new ImageView("view/resources/Redo.png");
        redoButton.setLayoutY(30);
        redoButton.setLayoutX(GAME_WIDTH-140);
        undoButton = new ImageView("view/resources/Undo.png");
        undoButton.setLayoutY(30);
        undoButton.setLayoutX(GAME_WIDTH-200);
        redoButton.setFitWidth(50);
        redoButton.setFitHeight(50);
        undoButton.setFitHeight(50);
        undoButton.setFitWidth(50);
        backButton = new ImageView("view/resources/Exit.png");
        backButton.setLayoutX(50);
        backButton.setLayoutY(30);
        backButton.setFitWidth(50);
        backButton.setFitHeight(50);
        saveButton.setOnMouseEntered(e->{
            saveButton.setEffect(new DropShadow());
        });
        saveButton.setOnMouseExited(e->{
            saveButton.setEffect(null);
        });
        saveButton.setOnMouseClicked(event -> {
            GameEngine.setGameInstance(startGameLogic);
            startGameLogic.saveGame();
        });
        undoButton.setOnMouseEntered(e->{
            undoButton.setEffect(new DropShadow());
        });
        undoButton.setOnMouseExited(e->{
            undoButton.setEffect(null);
        });
        redoButton.setOnMouseEntered(e->{
            redoButton.setEffect(new DropShadow());
        });
        redoButton.setOnMouseExited(e->{
            redoButton.setEffect(null);
        });
        backButton.setOnMouseEntered(e->{
            backButton.setEffect(new DropShadow());
        });
        backButton.setOnMouseExited(e->{
            backButton.setEffect(null);
        });

        backButton.setOnMouseClicked(e->{
            gameStage.close();
            ViewManger v = ViewManger.getInstance();
            v.resetScene();
            v.mainStage.show();
        });
        undoButton.setOnMouseClicked(e->{
            startGameLogic.undo();
        });
        redoButton.setOnMouseClicked(e->{
            startGameLogic.redo();
        });
    }

    //All the comming Functions are for Story one.
    public void creatNewGame(Stage menuStage, SHIP choosenShip, FARMER choosenFarmer, HERBANIMAL choosenHerbAnimal,
                             CARNANIMAL choosenCarnAnimal, PLANTS choosenPlants){
        this.choosenShip = choosenShip;
        this.choosenFarmer = choosenFarmer;
        this.choosenHerbAnimal = choosenHerbAnimal;
        this.choosenCarnAnimal = choosenCarnAnimal;
        this.choosenPlants = choosenPlants;
        storyNumber=1;
        this.menuStage = menuStage;
        this.menuStage.hide();
        creatBackground();
        creatShip(choosenShip);
        creatFarmer(choosenFarmer);
        creatCarnAnimal(choosenCarnAnimal);
        creatHerbAnimal(choosenHerbAnimal);
        creatPlant(choosenPlants);

        FarmerClicked();
        herbAnimalClicked();
        carnAnimalClicked();
        plantClicked();
        creatGameLoop();
        gameStage.show();
    }

    private void creatShip(SHIP choosenShip){
        idleship = new Image(choosenShip.getUrl());
        reversedShip = new Image(choosenShip.getReversedShipUrl());
        ship = new ImageView(reversedShip);
        if(choosenShip.getUrl().contains("boat_large_E")){
            ship.setFitHeight(100);
            ship.setFitWidth(250);
            ship.setLayoutY(GAME_HIGHT - 200);
        }else {
            ship.setFitHeight(200);
            ship.setFitWidth(250);
            ship.setLayoutY(GAME_HIGHT - 250);
        }
        ship.setLayoutX(550);
        gamePane.getChildren().addAll(ship);
    }
    private void creatFarmer(FARMER choosenFarmer){
        idleFarmer = new Image(choosenFarmer.getUrl());
        deadFarmer = new Image(choosenFarmer.getDeadFarmerUrl());
        JumpFarmer = new Image(choosenFarmer.getJumpFarmerUrl());
        farmerImage = new ImageView(idleFarmer);
        farmerImage.setFitHeight(160);
        farmerImage.setFitWidth(150);
        farmerImage.setLayoutY(GAME_HIGHT - 300);
        farmerImage.setLayoutX(GAME_WIDTH-150);
        gamePane.getChildren().addAll(farmerImage);
    }
    private void creatHerbAnimal(HERBANIMAL choosenHerbAnimal){
        idleHerbAnimal = new Image(choosenHerbAnimal.getUrl());
        selectedHerbAnimal = new Image(choosenHerbAnimal.getUrlherbSelectedAnimal());
        deadHerbAnimal = new Image(choosenHerbAnimal.getUrlherbDeadAnimal());
        herbAnimalImage = new ImageView(idleHerbAnimal);
        herbAnimalImage.setFitHeight(100);
        herbAnimalImage.setFitWidth(100);
        if(storyNumber==1){
            herbAnimalImage.setLayoutY(farmerImage.getLayoutY()+50);
            herbAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 80);
        }
        else if(storyNumber==2) {
            herbAnimalImage.setLayoutY(GAME_HIGHT - 320);
            herbAnimalImage.setLayoutX(GAME_WIDTH - 120);
        }
        gamePane.getChildren().addAll(herbAnimalImage);
    }
    private void creatCarnAnimal(CARNANIMAL choosenCarnAnimal){
        idleCarnAnimal = new Image(choosenCarnAnimal.getUrl());
        selectedCarnAnimal = new Image(choosenCarnAnimal.getUrlherbSelectedAnimal());
        deadCarnAnimal = new Image(choosenCarnAnimal.getUrlherbDeadAnimal());
        killCarnAnimal = new Image(choosenCarnAnimal.getUrlherbKillAnimal());
        carnAnimalImage = new ImageView(idleCarnAnimal);
        carnAnimalImage.setFitHeight(200);
        carnAnimalImage.setFitWidth(200);
        carnAnimalImage.setLayoutY(farmerImage.getLayoutY()-30);
        carnAnimalImage.setLayoutX(farmerImage.getLayoutX() - 150);
        gamePane.getChildren().addAll(carnAnimalImage);
    }
    private void creatPlant(PLANTS choosenPlant){
        plant = new Image(choosenPlant.getUrl());
        eatenPlant = new Image(choosenPlant.getUrlEatenPlant());
        plantImage = new ImageView(plant);
        plantImage.setFitHeight(100);
        plantImage.setFitWidth(100);
        plantImage.setLayoutY(farmerImage.getLayoutY()+50);
        plantImage.setLayoutX(herbAnimalImage.getLayoutX() - 80);
        gamePane.getChildren().addAll(plantImage);
    }
    private void creatGameLoop(){
        gameTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                moveShip();
                moveBackground();
                moveHerbAnimal();
                if(storyNumber==1) {
                    moveFarmer();
                    moveCarnAnimal();
                    movePlant();
                }
            }
        };
        gameTimer.start();
    }
    private void moveShip(){
        //Check first if the boat can be moved?
        if(letsgoButtonisClicked) {
            if(!startGameLogic.isBoatOnTheLeftBank()){
                if (angle < 6) {
                    angle += 2;
                }
                ship.setRotate(angle);
                if (ship.getLayoutX() >= 200) {
                    ship.setLayoutX(ship.getLayoutX() - 3);
                    endOfBank = false;
                    farmerImage.setLayoutX(farmerImage.getLayoutX() - 3);
                    if(boatRiders.contains(startGameLogic.herbanimal))
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 3);
                    else if(boatRiders.contains(startGameLogic.carnianimal))
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 3);
                    else if(boatRiders.contains(startGameLogic.planet))
                        plantImage.setLayoutX(plantImage.getLayoutX() - 3);
                } else {
                    endOfBank = true;
                    ship.setImage(idleship);
                    ship.setLayoutX(150);
                    startGameLogic.setLetsGoButtonClicked(false);
                }
            }
            else if (startGameLogic.isBoatOnTheLeftBank()) {
                if (angle > -6) {
                    angle -= 2;
                }
                ship.setRotate(angle);
                if (ship.getLayoutX() < 551) {
                    ship.setLayoutX(ship.getLayoutX() + 3);
                    endOfBank = false;
                    farmerImage.setLayoutX(farmerImage.getLayoutX() + 3);
                    if(boatRiders.contains(startGameLogic.herbanimal))
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() + 3);
                    else if(boatRiders.contains(startGameLogic.carnianimal))
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() + 3);
                    else if(boatRiders.contains(startGameLogic.planet))
                        plantImage.setLayoutX(plantImage.getLayoutX() + 3);
                } else {
                    endOfBank = true;
                    ship.setImage(reversedShip);
                    startGameLogic.setLetsGoButtonClicked(true);

                }
            }
            if (endOfBank) {
                angle = 0;
                ship.setRotate(angle);
                letsgoButtonisClicked = false;
            }
        }
    }
    private void FarmerClicked(){
        farmerImage.setOnMouseClicked(e->{
            System.out.println("Farmer Cliked");
            if(endOfBank) {
//                if(boatRiders.size()!=2){
                    System.out.println("IS Boat on left Side?? " + startGameLogic.isBoatOnTheLeftBank());
                    System.out.println("Is farmer on Right bank?" + startGameLogic.getCrossersOnRightBank().contains(startGameLogic.farmer));
                    System.out.println("Is farmer on Left bank?" + startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.farmer));
                    if (startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.farmer)
                            || !startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnRightBank().contains(startGameLogic.farmer)
                            || boatRiders.contains(startGameLogic.farmer)) {
                        System.out.println("Yes, ana farmer .. yes I can ride");
                        if (startGameLogic.getCrossersOnRightBank().contains(startGameLogic.farmer)&&boatRiders.size()!=2) {
                            boatRiders.add(startGameLogic.farmer);
                            startGameLogic.setCrossersOnboat(boatRiders);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1RightBankList.remove(startGameLogic.farmer);
                        } else if (startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.farmer)&&boatRiders.size()!=2) {
                            boatRiders.add(startGameLogic.farmer);
                            startGameLogic.setCrossersOnboat(boatRiders);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1LeftBankList.remove(startGameLogic.farmer);
                        } else if (boatRiders.contains(startGameLogic.farmer)) {
                            if (startGameLogic.isBoatOnTheLeftBank()) {
                                boatRiders.remove(startGameLogic.farmer);
                                System.out.println("List on boat now: " + boatRiders);
                                startGameLogic.story1LeftBankList.add(startGameLogic.farmer);
                                System.out.println("List on Left bank now: " + startGameLogic.story1LeftBankList);
                            } else {
                                boatRiders.remove(startGameLogic.farmer);
                                System.out.println("List on boat now: " + boatRiders);
                                startGameLogic.story1RightBankList.add(startGameLogic.farmer);
                                System.out.println("List on Right bank now: " + startGameLogic.story1RightBankList);
                            }
                    }
                    isFarmerClicked = true;
                }
                } else
                    isFarmerClicked = false;
//            }
//            else
//                isFarmerClicked =false;

        });

        farmerImage.setOnMouseEntered(e-> {
                farmerImage.setEffect(new DropShadow());
                farmerImage.setImage(JumpFarmer);
        });
        farmerImage.setOnMouseExited(e-> {
            farmerImage.setEffect(null);
            farmerImage.setImage(idleFarmer);
        });

    }
    private void farmerAclicked(){
        farmerA.setOnMouseClicked(e->{
        });

        farmerA.setOnMouseEntered(e-> {
            farmerA.setEffect(new DropShadow());
            farmerA.setImage(JumpFarmerA);
        });
        farmerA.setOnMouseExited(e-> {
            farmerA.setEffect(null);
            farmerA.setImage(idleFarmerA);
        });
    }
    private void farmerBclicked(){
        farmerB.setOnMouseClicked(e->{
        });

        farmerB.setOnMouseEntered(e-> {
            farmerB.setEffect(new DropShadow());
            farmerB.setImage(JumpFarmerB);
        });
        farmerB.setOnMouseExited(e-> {
            farmerB.setEffect(null);
            farmerB.setImage(idleFarmerB);
        });
    }
    private void farmerCclicked(){
        farmerC.setOnMouseClicked(e->{
        });

        farmerC.setOnMouseEntered(e-> {
            farmerC.setEffect(new DropShadow());
            farmerC.setImage(JumpFarmerC);
        });
        farmerC.setOnMouseExited(e-> {
            farmerC.setEffect(null);
            farmerC.setImage(idleFarmerC);
        });
    }
    private void farmerDclicked(){
        farmerD.setOnMouseClicked(e->{
        });

        farmerD.setOnMouseEntered(e-> {
            farmerD.setEffect(new DropShadow());
            farmerD.setImage(JumpFarmerD);
        });
        farmerD.setOnMouseExited(e-> {
            farmerD.setEffect(null);
            farmerD.setImage(idleFarmerD);
        });
    }
    private void herbAnimalClicked(){
        herbAnimalImage.setOnMouseClicked(e->{
            if(endOfBank) {
                    if (startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.herbanimal)
                            || !startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnRightBank().contains(startGameLogic.herbanimal)
                            || boatRiders.contains(startGameLogic.herbanimal)) {
                        if (startGameLogic.getCrossersOnRightBank().contains(startGameLogic.herbanimal)&&boatRiders.size()!=2) {
                            boatRiders.add(startGameLogic.herbanimal);
                            startGameLogic.setCrossersOnboat(boatRiders);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1RightBankList.remove(startGameLogic.herbanimal);
                        } else if (startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.herbanimal)&&boatRiders.size()!=2) {
                            boatRiders.add(startGameLogic.herbanimal);
                            startGameLogic.setCrossersOnboat(boatRiders);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1LeftBankList.remove(startGameLogic.herbanimal);
                        } else if (boatRiders.contains(startGameLogic.herbanimal)) {
                            if (startGameLogic.isBoatOnTheLeftBank()) {
                                boatRiders.remove(startGameLogic.herbanimal);
                                System.out.println("List on boat now: " + boatRiders);
                                startGameLogic.story1LeftBankList.add(startGameLogic.herbanimal);
                                System.out.println("List on Left bank now: " + startGameLogic.story1LeftBankList);
                            } else {
                                boatRiders.remove(startGameLogic.herbanimal);
                                System.out.println("List on boat now: " + boatRiders);
                                startGameLogic.story1RightBankList.add(startGameLogic.herbanimal);
                                System.out.println("List on Right bank now: " + startGameLogic.story1RightBankList);
                            }
                        }
                        isHerbAnimalClicked = true;
                    }
                } else
                    isHerbAnimalClicked = false;
        });

        herbAnimalImage.setOnMouseEntered(e-> {
            herbAnimalImage.setEffect(new DropShadow());
            herbAnimalImage.setImage(selectedHerbAnimal);
        });
        herbAnimalImage.setOnMouseExited(e-> {
            herbAnimalImage.setEffect(null);
            herbAnimalImage.setImage(idleHerbAnimal);
        });
    }
    private void carnAnimalClicked(){
        carnAnimalImage.setOnMouseClicked(e->{
            if(endOfBank) {
                if (startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.carnianimal)
                        || !startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnRightBank().contains(startGameLogic.carnianimal)
                        || boatRiders.contains(startGameLogic.carnianimal)) {
                    if (startGameLogic.getCrossersOnRightBank().contains(startGameLogic.carnianimal)&&boatRiders.size()!=2) {
                        boatRiders.add(startGameLogic.carnianimal);
                        startGameLogic.setCrossersOnboat(boatRiders);
                        System.out.println("List on boat now: " + boatRiders);
                        startGameLogic.story1RightBankList.remove(startGameLogic.carnianimal);
                    } else if (startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.carnianimal)&&boatRiders.size()!=2) {
                        boatRiders.add(startGameLogic.carnianimal);
                        startGameLogic.setCrossersOnboat(boatRiders);
                        System.out.println("List on boat now: " + boatRiders);
                        startGameLogic.story1LeftBankList.remove(startGameLogic.carnianimal);
                    } else if (boatRiders.contains(startGameLogic.carnianimal)) {
                        if (startGameLogic.isBoatOnTheLeftBank()) {
                            boatRiders.remove(startGameLogic.carnianimal);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1LeftBankList.add(startGameLogic.carnianimal);
                            System.out.println("List on Left bank now: " + startGameLogic.story1LeftBankList);
                        } else {
                            boatRiders.remove(startGameLogic.carnianimal);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1RightBankList.add(startGameLogic.carnianimal);
                            System.out.println("List on Right bank now: " + startGameLogic.story1RightBankList);
                        }
                    }
                    isCarnAnimalClicked = true;
                }
            } else
                isCarnAnimalClicked = false;
        });

        carnAnimalImage.setOnMouseEntered(e-> {
            carnAnimalImage.setEffect(new DropShadow());
            carnAnimalImage.setImage(selectedCarnAnimal);
        });
        carnAnimalImage.setOnMouseExited(e-> {
            carnAnimalImage.setEffect(null);
            carnAnimalImage.setImage(idleCarnAnimal);
        });
    }
    private void plantClicked(){
        plantImage.setOnMouseClicked(e->{
            if(endOfBank) {
                if (startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.planet)
                        || !startGameLogic.isBoatOnTheLeftBank() && startGameLogic.getCrossersOnRightBank().contains(startGameLogic.planet)
                        || boatRiders.contains(startGameLogic.planet)) {
                    if (startGameLogic.getCrossersOnRightBank().contains(startGameLogic.planet)&&boatRiders.size()!=2) {
                        boatRiders.add(startGameLogic.planet);
                        startGameLogic.setCrossersOnboat(boatRiders);
                        System.out.println("List on boat now: " + boatRiders);
                        startGameLogic.story1RightBankList.remove(startGameLogic.planet);
                    } else if (startGameLogic.getCrossersOnLeftBank().contains(startGameLogic.planet)&&boatRiders.size()!=2) {
                        boatRiders.add(startGameLogic.planet);
                        startGameLogic.setCrossersOnboat(boatRiders);
                        System.out.println("List on boat now: " + boatRiders);
                        startGameLogic.story1LeftBankList.remove(startGameLogic.planet);
                    } else if (boatRiders.contains(startGameLogic.planet)) {
                        if (startGameLogic.isBoatOnTheLeftBank()) {
                            boatRiders.remove(startGameLogic.planet);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1LeftBankList.add(startGameLogic.planet);
                            System.out.println("List on Left bank now: " + startGameLogic.story1LeftBankList);
                        } else {
                            boatRiders.remove(startGameLogic.planet);
                            System.out.println("List on boat now: " + boatRiders);
                            startGameLogic.story1RightBankList.add(startGameLogic.planet);
                            System.out.println("List on Right bank now: " + startGameLogic.story1RightBankList);
                        }
                    }
                    isPlantClicked = true;
                }
            } else
                isPlantClicked = false;
        });

        plantImage.setOnMouseEntered(e-> {
            plantImage.setEffect(new DropShadow());
        });
        plantImage.setOnMouseExited(e-> {
            plantImage.setEffect(null);
        });
    }
    private void movePlant(){
        if(isPlantClicked){
            if(boatRiders.contains(startGameLogic.planet)) {
                System.out.println("CARANIMAL is on boat");
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle < 6) {
                        angle += 2;
                    }
                    plantImage.setRotate(angle);


                    boatRiders.remove(startGameLogic.planet);
                    if(boatRiders.isEmpty()) {
                        if (plantImage.getLayoutX() > ship.getLayoutX()) {
                            plantImage.setLayoutX(plantImage.getLayoutX() - 3);
                        } else {
                            isPlantClicked = false;
                        }
                    }
                    else{
                        if(boatRiders.contains(startGameLogic.farmer)) {
                            if (plantImage.getLayoutX() > farmerImage.getLayoutX()+150) {
                                plantImage.setLayoutX(plantImage.getLayoutX() - 3);
                            } else {
                                isPlantClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.herbanimal)) {
                            if (plantImage.getLayoutX() > herbAnimalImage.getLayoutX()+150) {
                                plantImage.setLayoutX(plantImage.getLayoutX() - 3);
                            } else {
                                isPlantClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.carnianimal)) {
                            if (plantImage.getLayoutX() > carnAnimalImage.getLayoutX()+150) {
                                plantImage.setLayoutX(plantImage.getLayoutX() - 3);
                            } else {
                                isPlantClicked = false;
                            }
                        }
                    }
                    boatRiders.add(startGameLogic.planet);

                }
                else {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    plantImage.setRotate(angle);
                    if (plantImage.getLayoutX() < ship.getLayoutX()) {
                        plantImage.setLayoutX(plantImage.getLayoutX() + 3);
                    } else {
                        isPlantClicked = false;
                    }
                }
            }
            else{
                if(plantImage.getLayoutX()>=ship.getLayoutX()) {
                    if (plantImage.getLayoutX() < farmerImage.getLayoutX() && boatRiders.contains(startGameLogic.farmer))
                        farmerImage.setLayoutX(farmerImage.getLayoutX() - 100);
                    else if (plantImage.getLayoutX() < herbAnimalImage.getLayoutX() && boatRiders.contains(startGameLogic.herbanimal))
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 50);
                    else if (plantImage.getLayoutX() < carnAnimalImage.getLayoutX() && boatRiders.contains(startGameLogic.carnianimal))
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 100);
                }
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    plantImage.setRotate(angle);
                    if (plantImage.getLayoutX() <= GAME_WIDTH-450) {
                        plantImage.setLayoutX(plantImage.getLayoutX() + 3);
                    } else {
                        isPlantClicked = false;
                    }
                }
                else {
                    if (angle < 6) {
                        angle += 2;
                    }
                    plantImage.setRotate(angle);
                    if (plantImage.getLayoutX() >= 5) {
                        plantImage.setLayoutX(plantImage.getLayoutX() - 3);
                    } else {
                        isPlantClicked = false;
                    }
                }
            }
        }
        else{
            angle =0;
            plantImage.setRotate(angle);
        }
    }
    private void moveCarnAnimal(){
        if(isCarnAnimalClicked){
            if(boatRiders.contains(startGameLogic.carnianimal)) {
                System.out.println("CARANIMAL is on boat");
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle < 6) {
                        angle += 2;
                    }
                    carnAnimalImage.setRotate(angle);

                    boatRiders.remove(startGameLogic.carnianimal);
                    if(boatRiders.isEmpty()) {
                        if (carnAnimalImage.getLayoutX() > ship.getLayoutX()) {
                            carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 3);
                        } else {
                            isCarnAnimalClicked = false;
                        }
                    }
                    else{
                        if(boatRiders.contains(startGameLogic.farmer)) {
                            if (carnAnimalImage.getLayoutX() > farmerImage.getLayoutX()+150) {
                                carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 3);
                            } else {
                                isCarnAnimalClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.herbanimal)) {
                            if (carnAnimalImage.getLayoutX() > herbAnimalImage.getLayoutX()+150) {
//                                System.out.println("Why??????????????");
                                carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 3);
                            } else {
                                isCarnAnimalClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.planet)) {
                            if (carnAnimalImage.getLayoutX() > plantImage.getLayoutX()+150) {
                                carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 3);
                            } else {
                                isCarnAnimalClicked = false;
                            }
                        }
                    }
                    boatRiders.add(startGameLogic.carnianimal);

                }
                else {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    carnAnimalImage.setRotate(angle);
                    if (carnAnimalImage.getLayoutX() < ship.getLayoutX()) {
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() + 3);
                    } else {
                        isCarnAnimalClicked = false;
                    }
                }
            }
            else{
                if(carnAnimalImage.getLayoutX()>=ship.getLayoutX()) {
                    if (carnAnimalImage.getLayoutX() < farmerImage.getLayoutX() && boatRiders.contains(startGameLogic.farmer))
                        farmerImage.setLayoutX(farmerImage.getLayoutX() - 100);
                    else if (carnAnimalImage.getLayoutX() < herbAnimalImage.getLayoutX() && boatRiders.contains(startGameLogic.herbanimal))
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 50);
                    else if (carnAnimalImage.getLayoutX() < plantImage.getLayoutX() && boatRiders.contains(startGameLogic.planet))
                        plantImage.setLayoutX(plantImage.getLayoutX() - 50);
                }
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    carnAnimalImage.setRotate(angle);
                    if (carnAnimalImage.getLayoutX() <= GAME_WIDTH-350) {
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() + 3);
                    } else {
                        isCarnAnimalClicked = false;

                    }
                }
                else {
//                    if(carnAnimalImage.getLayoutX()<farmerImage.getLayoutX())
//                        farmerImage.setLayoutX(farmerImage.getLayoutX()-100);
                    if (angle < 6) {
                        angle += 2;
                    }
                    carnAnimalImage.setRotate(angle);
                    if (carnAnimalImage.getLayoutX() >= 70) {
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 3);
                    } else {
                        isCarnAnimalClicked = false;
                    }
                }
            }
        }
        else{
            angle =0;
            carnAnimalImage.setRotate(angle);
        }
    }
    private void moveHerbAnimal(){
        if(isHerbAnimalClicked){
            if(boatRiders.contains(startGameLogic.herbanimal)) {
                System.out.println("HerbAnimal is on boat");
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle < 6) {
                        angle += 2;
                    }

                    herbAnimalImage.setRotate(angle);

                    boatRiders.remove(startGameLogic.herbanimal);
                    if(boatRiders.isEmpty()) {
                        if (herbAnimalImage.getLayoutX() > ship.getLayoutX()) {
                            herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 3);
                        } else {
                            isHerbAnimalClicked = false;
                        }
                    }
                    else{
                        if(boatRiders.contains(startGameLogic.farmer)) {
                            if (herbAnimalImage.getLayoutX() > farmerImage.getLayoutX()+200) {
                                herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 3);
                            } else {
                                isHerbAnimalClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.carnianimal)) {
                            if (herbAnimalImage.getLayoutX() > carnAnimalImage.getLayoutX()+150) {
//                                System.out.println("Why??????????????");
                                herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 3);
                            } else {
                                isHerbAnimalClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.planet)) {
                            if (herbAnimalImage.getLayoutX() > plantImage.getLayoutX()+150) {
                                herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 3);
                            } else {
                                isHerbAnimalClicked = false;
                            }
                        }
                    }
                    boatRiders.add(startGameLogic.herbanimal);
                }
                else {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    herbAnimalImage.setRotate(angle);
                    if (herbAnimalImage.getLayoutX() < ship.getLayoutX()) {
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() + 3);
                    } else {
                        isHerbAnimalClicked = false;
                    }
                }
            }
            else{
                if(herbAnimalImage.getLayoutX()>=ship.getLayoutX()) {
                    if (herbAnimalImage.getLayoutX() < farmerImage.getLayoutX() && boatRiders.contains(startGameLogic.farmer))
                        farmerImage.setLayoutX(farmerImage.getLayoutX() - 50);
                    else if (herbAnimalImage.getLayoutX() < carnAnimalImage.getLayoutX() && boatRiders.contains(startGameLogic.carnianimal))
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 100);
                    else if (herbAnimalImage.getLayoutX() < plantImage.getLayoutX() && boatRiders.contains(startGameLogic.planet))
                        plantImage.setLayoutX(plantImage.getLayoutX() - 50);
                }
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    herbAnimalImage.setRotate(angle);
                    if (herbAnimalImage.getLayoutX() <= GAME_WIDTH-250) {
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() + 3);
                    } else {
                        isHerbAnimalClicked = false;
                    }
                }
                else {
                    if (angle < 6) {
                        angle += 2;
                    }
                    herbAnimalImage.setRotate(angle);
                    if (herbAnimalImage.getLayoutX() >= 40) {
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 3);
                    } else {
                        isHerbAnimalClicked = false;
                    }
                }
            }
        }
        else{
            angle =0;
            herbAnimalImage.setRotate(angle);
        }
    }
    private void moveFarmer(){
        if(isFarmerClicked) {
            if(boatRiders.contains(startGameLogic.farmer)) {
                System.out.println("Farmer is on boat");
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle < 6) {
                        angle += 2;
                    }
                    farmerImage.setRotate(angle);
                    boatRiders.remove(startGameLogic.farmer);
                    if(boatRiders.isEmpty()) {
                        if (farmerImage.getLayoutX() > ship.getLayoutX()) {
                            System.out.println("blaaa");
                            farmerImage.setLayoutX(farmerImage.getLayoutX() - 3);
                        } else {
                            isFarmerClicked = false;
                        }
                    }
                    else{
                        if(boatRiders.contains(startGameLogic.herbanimal)) {
                            if (farmerImage.getLayoutX() > herbAnimalImage.getLayoutX()+100) {
                                farmerImage.setLayoutX(farmerImage.getLayoutX() - 3);
                            } else {
                                isFarmerClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.carnianimal)) {
                            if (farmerImage.getLayoutX() > carnAnimalImage.getLayoutX()+100) {
//                                System.out.println("Why??????????????");
                                farmerImage.setLayoutX(farmerImage.getLayoutX() - 3);
                            } else {
                                isFarmerClicked = false;
                            }
                        }
                        else if(boatRiders.contains(startGameLogic.planet)) {
                            if (farmerImage.getLayoutX() > plantImage.getLayoutX()+100) {
                                farmerImage.setLayoutX(farmerImage.getLayoutX() - 3);
                            } else {
                                isFarmerClicked = false;
                            }
                        }
                    }
                    boatRiders.add(startGameLogic.farmer);
                }
                else {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    farmerImage.setRotate(angle);
                    if (farmerImage.getLayoutX() < ship.getLayoutX()) {
                        farmerImage.setLayoutX(farmerImage.getLayoutX() + 3);
                    } else {
                        isFarmerClicked = false;
                        }
                }
            }
            else{
                System.out.println("Farmer isn't on boat");
                if(farmerImage.getLayoutX()>=ship.getLayoutX()) {
                    if (farmerImage.getLayoutX() < carnAnimalImage.getLayoutX() && boatRiders.contains(startGameLogic.carnianimal))
                        carnAnimalImage.setLayoutX(carnAnimalImage.getLayoutX() - 100);
                    else if (farmerImage.getLayoutX() < herbAnimalImage.getLayoutX() && boatRiders.contains(startGameLogic.herbanimal))
                        herbAnimalImage.setLayoutX(herbAnimalImage.getLayoutX() - 50);
                    else if (farmerImage.getLayoutX() < plantImage.getLayoutX() && boatRiders.contains(startGameLogic.planet))
                        plantImage.setLayoutX(plantImage.getLayoutX() - 50);
                }
                if (!startGameLogic.isBoatOnTheLeftBank()) {
                    if (angle > -6) {
                        angle -= 2;
                    }
                    farmerImage.setRotate(angle);
                    if (farmerImage.getLayoutX() <= GAME_WIDTH-150) {
                        farmerImage.setLayoutX(farmerImage.getLayoutX() + 3);
                    } else {
                        isFarmerClicked = false;
                    }
                }
                else {
                    if (angle < 6) {
                        angle += 2;
                    }
                    farmerImage.setRotate(angle);
                    if (farmerImage.getLayoutX() >= 40) {
                        farmerImage.setLayoutX(farmerImage.getLayoutX() - 3);
                    } else {
                        isFarmerClicked = false;
                    }
                }
            }
        }
        else{
            angle =0;
            farmerImage.setRotate(angle);
        }
    }


    private void creatBackground(){
        gridPane1 = new GridPane();
        gridPane2 = new GridPane();
        for(int i=0;i<12;i++){
            ImageView backgroundImage1 = new ImageView(BACKGROUND_IMAGE2);
            ImageView backgroundImage2 = new ImageView(BACKGROUND_IMAGE2);
            GridPane.setConstraints(backgroundImage1, i%3, 0);
            GridPane.setConstraints(backgroundImage2, i%3, 0);
            backgroundImage1.setFitWidth(1250);
            backgroundImage2.setFitWidth(1250);
            backgroundImage1.setFitHeight(300);
            backgroundImage2.setFitHeight(300);
            gridPane1.getChildren().add(backgroundImage1);
            gridPane2.getChildren().add(backgroundImage2);
        }
        gridPane2.setLayoutX(-1250);
        gamePane.getChildren().addAll(gridPane1,gridPane2);
        ImageView backgroundImage3 = new ImageView(BACKGROUND_IMAGE);
        backgroundImage3.setFitWidth(1250);
        backgroundImage3.setLayoutY(300);
        backgroundImage3.setFitHeight(400);
        gamePane.getChildren().addAll(backgroundImage3,createLetsGoButton(),saveButton,redoButton,undoButton,backButton);
    }

    private void moveBackground(){
        gridPane1.setLayoutX(gridPane1.getLayoutX() + 0.5);
        gridPane2.setLayoutX(gridPane2.getLayoutX()+0.5);
        if(gridPane1.getLayoutX()>=1250){
            gridPane1.setLayoutX(-1250);
        }
        if(gridPane2.getLayoutX() >= 1250){
            gridPane2.setLayoutX(-1250);
        }
    }

    public void creatStoryTwoGame(Stage menuStage, SHIP choosenShip, HERBANIMAL choosenHerbAnimal){
        storyNumber=2;
        this.menuStage = menuStage;
        this.menuStage.hide();
        creatBackground();
        creatShip(choosenShip);
        creatFarmerA();
        creatFarmerB();
        creatFarmerC();
        creatFarmerD();
        farmerAclicked();
        farmerBclicked();
        farmerCclicked();
        farmerDclicked();
        creatHerbAnimal(choosenHerbAnimal);
        herbAnimalClicked();
        creatGameLoop();
        gameStage.show();
    }
    private void creatFarmerA(){
        idleFarmerA = new Image("view/resources/fourFarmer/adventurer_idle.png");
        JumpFarmerA = new Image("view/resources/fourFarmer/adventurer_jump.png");
        farmerA = new ImageView(idleFarmerA);
        farmerA.setFitHeight(120);
        farmerA.setFitWidth(120);
        farmerA.setLayoutX(GAME_WIDTH - 250);
        farmerA.setLayoutY(GAME_HIGHT-350);
        gamePane.getChildren().add(farmerA);
    }
    private void creatFarmerB(){
        idleFarmerB = new Image("view/resources/fourFarmer/female_idle.png");
        JumpFarmerB = new Image("view/resources/fourFarmer/female_jump.png");
        farmerB = new ImageView(idleFarmerB);
        farmerB.setFitHeight(120);
        farmerB.setFitWidth(120);
        farmerB.setLayoutX(farmerA.getLayoutX() - 100);
        farmerB.setLayoutY(farmerA.getLayoutY());
        gamePane.getChildren().add(farmerB);
    }
    private void creatFarmerC(){
        idleFarmerC = new Image("view/resources/fourFarmer/player_idle.png");
        JumpFarmerC = new Image("view/resources/fourFarmer/player_jump.png");
        farmerC = new ImageView(idleFarmerC);
        farmerC.setFitHeight(120);
        farmerC.setFitWidth(120);
        farmerC.setLayoutX(farmerB.getLayoutX() - 100);
        farmerC.setLayoutY(farmerA.getLayoutY());
        gamePane.getChildren().add(farmerC);
    }
    private void creatFarmerD(){
        idleFarmerD = new Image("view/resources/fourFarmer/soldier_idle.png");
        JumpFarmerD = new Image("view/resources/fourFarmer/soldier_jump.png");
        farmerD = new ImageView(idleFarmerD);
        farmerD.setFitHeight(120);
        farmerD.setFitWidth(120);
        farmerD.setLayoutX(farmerC.getLayoutX() - 100);
        farmerD.setLayoutY(farmerA.getLayoutY());
        gamePane.getChildren().add(farmerD);
    }
}