package Logic;
import java.beans.XMLEncoder;
import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.FileOutputStream;
import java.util.*;
import javax.xml.bind.annotation.*;

public class SAVEXML {
    GameEngine Game = GameEngine.getGameInstance();

void File_Save(){
    try

    {
//    File file = new File("D:\\Downloads\\RiverCrosser--master\\RiverCrosser--master\\src\\Logic\\file.xml");
        FileOutputStream fos = new FileOutputStream(new File("D:\\\\Downloads\\\\RiverCrosser--master\\\\RiverCrosser--master\\\\src\\\\Logic\\\\file.xml"));
        XMLEncoder encode = new XMLEncoder(fos);
        encode.writeObject(Game);
        encode.close();
        fos.close();
    }
    catch (Exception e) {
        e.printStackTrace();
    }
}





}


