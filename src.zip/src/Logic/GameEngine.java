package Logic;


import java.util.LinkedList;
import java.util.List;
import java.util.Stack;


public class GameEngine implements IRiverCrossingController {
   public Farmer farmer;
    public Planet planet;
    public Carnianimal carnianimal;
    int countt = 0;
    boolean CANREDO = false;
    public Herbanimal herbanimal;
    public Stack ReDo;
    public Stack UnDo;
    public List<List<ICrosser>> Redo =  new LinkedList<List<ICrosser>>();
    public List<List<ICrosser>> Undo=  new LinkedList<List<ICrosser>>();


    public List<ICrosser> storyOneList = new LinkedList<ICrosser>();
    public List<ICrosser> story1RightBankList = new LinkedList<ICrosser>();
    public List<ICrosser> story1LeftBankList = new LinkedList<ICrosser>();
    public List<ICrosser> boatRiders = new LinkedList<ICrosser>();
    private boolean letsGoButtonClicked;
    public int storyType;

    public void setStoryType(int x ){
        this.storyType = x;
    }
    public void newGame(ICrosseingStrategy gameStrategy) {
        if(storyType==1){
            this.farmer = new Farmer(10,0);
            this.planet = new Planet();
            this.carnianimal = new Carnianimal();
            this.herbanimal = new Herbanimal();
            this.UnDo = new Stack();
            this.ReDo = new Stack();
//            this.Redo = new LinkedList<<ICrosser >>();
            Story1Logic.getInstance().setObjects(this.farmer,this.planet,herbanimal,carnianimal);
            this.storyOneList = Story1Logic.getInstance().getIntialICrossers();
            this.story1RightBankList.addAll(storyOneList);
                    //= this.storyOneList;
            boatRiders = null;

        }
        else{

        }
    }

    public List<ICrosser> getWinnerfromLogic(){
        return Story1Logic.getInstance().getWinner();
    }
    public boolean isValidforBoat(List<ICrosser> boatRiders){
        if(boatRiders.contains(farmer))
            return true;
        return false;
    }
    public boolean isValidFromLogic(List<ICrosser> rightBankCrossers, List<ICrosser> leftBankCrossers, List<ICrosser> boatRiders){
        System.out.println("I recieved: "+rightBankCrossers + leftBankCrossers + boatRiders);
        return Story1Logic.getInstance().isValid(rightBankCrossers,leftBankCrossers,boatRiders);
    }
    public void resetGame() {
        this.story1RightBankList = Story1Logic.getInstance().getIntialICrossers();

        this.story1LeftBankList =null;
        this.boatRiders = null;
        this.boatRiders = new LinkedList<ICrosser>();
        this.story1LeftBankList = new LinkedList<ICrosser>();


    }

    public String[] getInstructions() {
        return new String[0];
    }

    public List<ICrosser> getCrossersOnRightBank() {
        System.out.println("Right bank List: "+this.story1RightBankList);
        return this.story1RightBankList;
    }

    public List<ICrosser> getCrossersOnLeftBank() {
        return story1LeftBankList;

    }
    public List<ICrosser> getCrossersOnboat() {
        return boatRiders;
    }
    public void setCrossersOnboat(List<ICrosser> boatRiders){
        this.boatRiders = boatRiders;
    }

    public void setLetsGoButtonClicked( boolean letsGoButtonClicked){
        this.letsGoButtonClicked = letsGoButtonClicked;
    }
    public boolean isBoatOnTheLeftBank() {
        if(letsGoButtonClicked)
            return false;
        return true;
    }

    public int getNumberOfSails() {
        return 0;
    }

    public boolean canMove(List<ICrosser> crossers, boolean fromLeftTorightBank) {
        return false;
    }

    public boolean doMove(List<ICrosser> crossers, boolean fromLeftTorightBank) {
        return false;
    }

    public boolean canDo() {
        return false;
    }

    public boolean canReDo() {

        if (!ReDo.empty())
            return true;
        else
            return false;
    }

    public void undo() {
        LinkedList<List<ICrosser>> Alist;
        if(!UnDo.empty())
        {
            Alist= (LinkedList<List<ICrosser>>)UnDo.pop();
            this.story1RightBankList=null;
            this.story1RightBankList= new LinkedList<ICrosser>();
            this.story1LeftBankList=null;
            this.story1LeftBankList= new LinkedList<ICrosser>();
            this.story1RightBankList.addAll( Alist.get(0));
            this.story1LeftBankList = Alist.get(1);
            System.out.println("ali: Undo "+story1RightBankList+"---Alii---- "+story1LeftBankList);

            this.ReDo.push((LinkedList<List<ICrosser>>)Alist);
        }
        else
            System.out.println("FADYYAAAA");
    }

    public void redo() {
        LinkedList<List<ICrosser>> Alist =  new LinkedList<>();
        if(canReDo())
        {
          Alist= (LinkedList<List<ICrosser>>) ReDo.pop();
            System.out.println("111"+Alist.get(0)+"222"+Alist.get(1));
          this.story1RightBankList = Alist.get(0);
          this.story1LeftBankList = Alist.get(1);
            System.out.println("ali: REDO "+story1RightBankList+"Alii "+story1LeftBankList);
          UnDo.push( (LinkedList<List<ICrosser>>) Alist);
        }
            else
            System.out.println("FADYAAA NEEEK");
    }

    public void saveGame() {

    }

    public void loadGame() {

    }
    public void  REDOLIST(){
         LinkedList<List<ICrosser>> Alist = new LinkedList<>();
         Alist.add(story1RightBankList);
         Alist.add(story1LeftBankList);

        UnDo.push(Alist);


    }
    public void IniStacks(){
        this.UnDo = null;
        this.ReDo =null;
        this.UnDo = new Stack();
        this.ReDo = new Stack();



    }
}
