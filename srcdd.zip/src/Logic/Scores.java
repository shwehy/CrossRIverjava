package Logic;

public class Scores {
    short Level;
    int score;
    String Player;
    public Scores(short level , int score, String Player){
        this.Level = level;
        this.score = score;
        this.Player = Player;
    }
}
